var loginAuth = {
    login:function(loginData){

        adr = 'localhost:5000/'+loginCredentials['username'];
        alert(adr);

        $.getJSON(adr, function(result){

        if ((result!=null)&(result['password']==loginCredentials['password'])){
            $.mobile.changePage( "#index", { transition: "slide"} );
        }
        else{
            alert('Erreur Login, rééssayez');
        }
    }); 

    }
}


$.ajax({
  dataType: 'json',
  url: adr,
  success: function (result) {
    alert('success');
  },
});


ajaxGet("localhost:5000/"+loginCredentials['username'], function (reponse) {
alert('success');
});

$.getJSON('localhost:5000/entreprises', function(data){
    alert('success');
});