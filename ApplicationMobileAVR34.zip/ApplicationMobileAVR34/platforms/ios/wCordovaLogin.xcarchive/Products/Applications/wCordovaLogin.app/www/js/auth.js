$.support.cors=true;



function auth(loginData, callback){
		console.log(loginData);
		$.ajax({

			type : 'GET',
			//url: 'http://localhost:5000/entreprises/'+loginData.username,
			url: 'http://127.0.0.1:5000/entreprises/'+loginData.username,
			dataType: 'json',
			success: function (result) {



				if(result.password == loginData.password) {

					//window.localStorage.setItem("loggedIn", 1);
					//window.localStorage.setItem("username", loginData.username);
					//document.getElementById("password").value = "";
					callback('success',result);
					//secteurUser = result.activite;
					//$.mobile.changePage( "#index");
					
				} 

				else {


					callback('credentialsError',null);
				
				}

			},

			error: function (request,error) {

				callback('requestError',null);
				
			}
		});
}

