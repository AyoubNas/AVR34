	var loginCredentials = { username : "", password : "" }; //stocke les infos temporairement lors de la connexion au compte de l'entreprise
	var user;//stocke les infos de l'entreprise pendant l'utilisation de l'application
	var details = {nomEnt : "", descDemande : "", etatDemande : "", _created : ""}; // stocke temporairement les infos d'une demande lorsqu'on affiche les détails
	var mesDemandes = [];// stocke les demandes récupérées via l'api
	var autorefresh; //variable permettant de mettre en place le chargement régulier des nouvelles demandes (ctrl-f)
	var tailleListe = 0; //variables permettant de vérifier la présence de nouvelles demandes
	var tailleListeInit = 0;


	$.support.cors=true;

	function updateList(data){ //ajoute dans la page les demandes chargées depuis l'api ET envoie la notif + alerte si nouvelles demandes
		console.log('babababababab');

						tailleListeInit = tailleListe;
						tailleListe = data.length;

						if(tailleListeInit == 0 && tailleListe != tailleListeInit)
						{
							
							alert("Il y a " + data.length + " demandes liées à votre secteur d'activité" );
							
						}

						else 
						{
							if (tailleListe != tailleListeInit)
							{	

								test = tailleListe - tailleListeInit;
								//notify(1); // décommenter la ligne lorsque tout sera en place (impossible de tester sur émulateur, et impossible de lancer sur mobile car pas d'api !)
								alert("Vous avez " + test + " nouvelles demandes" );

							}
						}

   $('#list').empty(); 
for( var i=0; i<data.length; i++){


	

									
								if(data[i].villeEnt == undefined || data[i].cpEnt == undefined)
										{
                                 			if(data[i].nomContact == undefined)
                                 			{
                                 				
                                 				$('#list').append('<li>  <a id = '+data[i]._id+' href=#detail ><h2>' + data[i].nomEnt + '</h2><p>' +  data[i].descDemande + '</p><p><strong>' +'(' +data[i].etatDemande +  ')'+'</strong></p></a></li>').listview('refresh');	

                                 			}
                                 			else
                                 			{
                                 		
                                 				$('#list').append('<li>  <a id = '+data[i]._id+' href=#detail ><h2>' + data[i].nomContact + ' | '+ data[i].nomEnt + '</h2><p>' +data[i].descDemande + '</p><p><strong>' + '(' +data[i].etatDemande +')' +'</strong></p></a></li>').listview('refresh');	

                                 			}
										}
									else
									{
										if(data[i].nomContact == undefined)
                                 			{
                                 				
										$('#list').append('<li>  <a id = '+data[i]._id+' href=#detail ><h2>' + data[i].nomEnt + '</h2><p>' + data[i].descDemande + '</p><p><strong>' + '('+  data[i].etatDemande + ')'+ '</strong></p>'+ data[i].villeEnt + " -- "+ data[i].cpEnt +'</a></li>').listview('refresh');	

                                 			}
                                 			else
                                 			{
                                 			
										$('#list').append('<li>  <a id = '+data[i]._id+' href=#detail ><h2>' + data[i].nomContact + ' | '+ data[i].nomEnt + '</h2><p>' + data[i].descDemande + '</p><p><strong>' + '(' +data[i].etatDemande +')' +'</strong></p><p>'+ data[i].villeEnt + " -- "+ data[i].cpEnt +'</p></a></li>').listview('refresh');	

                                 			}
									}

						td = document.getElementById(data[i]._id);  //ajout de l'action au clic sur une demandes
       					(function (_td) {
       						
	           				td.addEventListener('click', function(){
	           				
	                			toDetail(_td.id);
	           				});
       					})(td);

						
						}
          
            
					}
		  
		     
		


	function notify(nb){  // fonction qui envoie la notification : l'absence d'api empeche de tester cette fonction, elle devra éventuellement être réécrite quand l'api sera prête
		console.log('wilnotify');

		if (localStorage.getItem("notif")==undefined){
			console.log('notif : undefined');
		cordova.plugins.notification.local.registerPermission(function (granted) {
			if (granted){
				console.log('notif granted');
				localStorage.setItem("notif","true");
			}
			else {
				console.log('notif not granted');
				localStorage.setItem("notif","false");
			}

		});
	}
	else {
		cordova.plugins.notification.local.hasPermission(function (granted) {

			if(granted){

			cordova.plugins.notification.local.schedule({
    title: "nouvelle(s) demande(s)",
    message: "de nouvelles demandes sont disponibles",

});
		}
});
	}

	}
	
	



	function setupPageLogin(){  // à la création de la page de login



		window.localStorage.setItem("loggedIn", 0);


		$.support.cors=true;

	    $('#login-button').on('click', function(){

	        if($('#username').val().length > 0 && $('#password').val().length > 0){

	            loginCredentials.username = $('#username').val();
	            loginCredentials.password = $('#password').val();  
	            auth(loginCredentials, handleAuth);  // appel de la fonction d'authentification avec callback
	        
	        }

	        else {

	            alert('all fields are required');
	        }
	    });  
	}

	function handleAuth(msg,data){  // gère le retour de la fonction auth
		switch(msg) {
    case 'success':
    	user=data;
    	loginCredentials={ username : "", password : "" };
    	document.getElementById("password").value=""; 
    	window.localStorage.setItem("loggedIn", 1);

		autorefresh = setInterval(
			function(){ 

				getDemandes(user.activite,updateList); 

			}, 600000);

    	


        $.mobile.changePage( "#index");
        break;
    case 'credentialsError':
        alert('mauvais mdp ou nom d\'utilisateur');
        break;
    case 'requestError':
        alert('erreur, rééssayez plus tard');
		} 

	}


	function beforeShowPageLogin(){ // afficher la liste des demandes (page home) si l'utilisateur est déjà connecté


		if(window.localStorage.getItem("loggedIn") == 1){

	        $.mobile.changePage( "#index", { transition: "none"} );
	    }


	}

	function beforeShowPageHome(){ // renvoie au login si l'utilisateur est déconnecté, sinon met en place le rechargement des demandes

		$.support.cors=true;
		

	
		if(window.localStorage.getItem("loggedIn") == 1){

			$('#logout-button').on('click', function(){


				clearInterval(autorefresh);
				window.localStorage.setItem("loggedIn", 0);
				$('#headTitle').empty();
				$.mobile.changePage( "#login", {transition : "pop"} );


			});

			$('#refresh-button').on('click', function(){ // bouton "recharger"


			getDemandes(user.activite,updateList); // appel de la fonction de récupération des demandes avec callback


			});	

		    getDemandes(user.activite,updateList); // appel de la fonction de récupération des demandes avec callback

		    $(this).find('[data-role="header"] h3').empty();
		    $(this).find('[data-role="header"] h3').append('connecté : ' + user.nomEnt);	   //édition du header avec nom de l'entreprise  	  
		     
		}else{

			$.mobile.changePage( "#login", { transition: "none"} );
		}



	}

	function setupPageHome(){  // renvoie au login si l'utilisateur est déconnecté

		if(window.localStorage.getItem("loggedIn") == 0){

	        $.mobile.changePage( "#login", { transition: "none"} );
	    }else{

	    		
	    }


	}



	function beforeShowDetail(){ 


		if(window.localStorage.getItem("loggedIn") == 0){

	        $.mobile.changePage( "#login", { transition: "none"} );
	    }

		$('#Retour-button').on('click', function(){
			$('#nomEnt').empty();
			$('#descDemande').empty();
			$('#etatDemande').empty();
			$.mobile.changePage( "#index", {transition : "slide"} );

		});


	
	}


		

	

	function toDetail(data){ //recupere les details de la demande cliquée pour l'afficher (updateDetail)
		console.log('toDetail id : '+data);

		getOneDemande(data,updateDetail);
		$.mobile.changePage( "#detail", { transition: "none"} );

	}

	function updateDetail(data){ // affiche les details de la demande  et prépare les infos nécessaires à l'envoi du mail (json) pour les envoyer à l'api

		var mail = { 
			idEntreprise : user._id,
			idDemande : data._id,
			
		}

		$('#nomEnt').append("<h1>"+ data.nomEnt + "</h1>");
		$('#descDemande').append( data.descDemande);
		$('#etatDemande').append( data.etatDemande );



		$('#send').on('click', function(){

			mail.mailText = $("#mailText").val();
			sendMail(mail, mailSent); // appel de la fonction d'envoi du mail avec callback

		});




	}

	function mailSent(data){ // affiche une alerte si echec d'envoi,  sinon affiche une alerte et vide le champ texte
	

		if (data == "error"){
			alert('echec de l\'envoi du mail');


		}
		else {
			alert('message envoyé ');
			document.getElementById("mailText").value=""; 

		}
	}




	$(document).on('pagecreate', '#login', setupPageLogin);
	$(document).on('pagecreate', '#index', setupPageHome);
	$(document).on('pagebeforeshow', '#login', beforeShowPageLogin);
	$(document).on('pagebeforeshow', '#index', beforeShowPageHome);
	$(document).on('pagebeforeshow', '#detail', beforeShowDetail);


	
