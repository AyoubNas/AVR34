$.support.cors=true;

function sendMail(data, callback){

	$.ajax({
		
	    type: "POST",
	    url: "http://localhost:5000/sendMail",
	    // The key needs to match your method's input parameter (case-sensitive).
	    data: JSON.stringify(data),
	    contentType: "application/json; charset=utf-8",
	    dataType: "json",
	    success: function(result){
	    	callback(result);
	    },
	    failure: function(errMsg) {
	        callback("error");
	    }
	});
}

