$.support.cors=true;

	var tailleListe = 0; 
	var tailleListeInit = 0;



function getDemandes(secteur,callback){

	var demandes= [];
	var dem = {
								_id : "",
								nomEnt : "",
								adresseEnt :"" ,
								cpEnt :"" ,
								villeEnt :"" ,
								telEnt : "", 
								mailEnt :"" , 
								secteurDemande :"" , 
								descDemande :"" , 
								etatDemande :"" }
	var res;
	
		
				$.ajax({
					type : 'GET',
			        url: 'http://localhost:5000/demandes?where={%22secteurDemande%22:%20%22' + secteur + '%22}',
			   		dataType: 'json',


			   		beforeSend: function() {
			   			console.log('beforeSend')
			   			$.mobile.loading('show');
			   		},
			   		complete: function() {
			   			$.mobile.loading('hide');
			   		},


					success: function (result) {
					    	
						for (var i=0; i<result._items.length; i++){
								
								
								demandes.push(
									{
								_id : result._items[i]._id,
								nomEnt :result._items[i].nomEnt ,
								adresseEnt :result._items[i].adresseEnt ,
								cpEnt : result._items[i].cpEnt,
								villeEnt : result._items[i].villeEnt,
								telEnt : result._items[i].telEnt, 
								mailEnt : result._items[i].mailEnt, 
								secteurDemande :result._items[i].secteurDemande , 
								descDemande : result._items[i].descDemande, 
								etatDemande : result._items[i].etatDemande}
								);
								console.log(demandes[i]._id);
								console.log('i : ' +i);
								console.log(demandes);
						}
							tailleListeInit = tailleListe;

						tailleListe = result._items.length;
						if(tailleListeInit == 0 && tailleListe != tailleListeInit)
						{
							alert("Il y a " + result._items.length + " demandes lies a votre secteur d'activité" );
							
						}

						else 
						{
							if (tailleListe != tailleListeInit)
							{	

								test = tailleListe - tailleListeInit;

								alert("Vous avez " + test + " nouvelles demandes" );
							}
						}
						demandes.reverse();
						callback(demandes);

					
					},

					error: function (request,error) {
					callback('erreur demandes');

					}

			});

			
			return;
}


function getOneDemande(id,callback){

		var dem = {
								_id : "",
								nomEnt : "",
								adresseEnt :"" ,
								cpEnt :"" ,
								villeEnt :"" ,
								telEnt : "", 
								mailEnt :"" , 
								secteurDemande :"" , 
								descDemande :"" , 
								etatDemande :"" }

	$.ajax({
		type : 'GET',
	    url: 'http://localhost:5000/demandes/'+id,
			dataType: 'json',


		success: function (result) {
			


								dem._id = result._id;
								dem.nomEnt = result.nomEnt;
								dem.adresseEnt =result.adresseEnt ;
								dem.cpEnt =result.cpEnt ;
								dem.villeEnt =result.villeEnt ;
								dem.telEnt =result.telEnt ; 
								dem.mailEnt =result.mailEnt ;
								dem.secteurDemande =result.secteurDemande;
								dem.descDemande =result.descDemande ; 
								dem.etatDemande =result.etatDemande;
								callback(dem);
		
		},

		error: function (request,error) {

			callback('impossible de récupérer les détails');

		}

	});


}
