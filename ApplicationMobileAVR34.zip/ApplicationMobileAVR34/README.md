# wCordova-template-login
template of login page cordova application

## Install

install nodejs

> sudo apt-get install nodejs

> sudo apt-get install nodejs-legacy

install npm

> sudo apt-get install npm

install cordova

> sudo npm install -g cordova

## build android application

add android platform

> cordova platform add android

build (assume $ANDROID_HOME is set)

> cordova build

## launch application

> cordova emulate android
