	var loginCredentials = { username : "", password : "" };
	var user;
	var details = {nomEnt : "", descDemande : "", etatDemande : "", _created : ""};
	var mesDemandes = [];
	var secteurUser;
	var autorefresh;


	$.support.cors=true;

	function updateList(data){

   $('#list').empty();
for( var i=0; i<data.length; i++){


	

									
								if(data[i].villeEnt == undefined || data[i].cpEnt == undefined)
										{
                                 			if(data[i].nomContact == undefined)
                                 			{
                                 				
                                 				$('#list').append('<li>  <a id = '+data[i]._id+' href=#detail ><h2>' + data[i].nomEnt + '</h2><p>' +  data[i].descDemande + '</p><p><strong>' +'(' +data[i].etatDemande +  ')'+'</strong></p></a></li>').listview('refresh');	

                                 			}
                                 			else
                                 			{
                                 		
                                 				$('#list').append('<li>  <a id = '+data[i]._id+' href=#detail ><h2>' + data[i].nomContact + ' | '+ data[i].nomEnt + '</h2><p>' +data[i].descDemande + '</p><p><strong>' + '(' +data[i].etatDemande +')' +'</strong></p></a></li>').listview('refresh');	

                                 			}
										}
									else
									{
										if(data[i].nomContact == undefined)
                                 			{
                                 				
										$('#list').append('<li>  <a id = '+data[i]._id+' href=#detail ><h2>' + data[i].nomEnt + '</h2><p>' + data[i].descDemande + '</p><p><strong>' + '('+  data[i].etatDemande + ')'+ '</strong></p>'+ data[i].villeEnt + " -- "+ data[i].cpEnt +'</a></li>').listview('refresh');	

                                 			}
                                 			else
                                 			{
                                 			
										$('#list').append('<li>  <a id = '+data[i]._id+' href=#detail ><h2>' + data[i].nomContact + ' | '+ data[i].nomEnt + '</h2><p>' + data[i].descDemande + '</p><p><strong>' + '(' +data[i].etatDemande +')' +'</strong></p><p>'+ data[i].villeEnt + " -- "+ data[i].cpEnt +'</p></a></li>').listview('refresh');	

                                 			}
									}

						td = document.getElementById(data[i]._id);
       					(function (_td) {
       						
	           				td.addEventListener('click', function(){
	           				
	                			toDetail(_td.id);
	           				});
       					})(td);

						
						}
          
            
					}
		  
		     
		


	
	



	function setupPageLogin(){
	console.log('setupPageLogin : connected : '+window.localStorage.getItem("loggedIn"));

		window.localStorage.setItem("loggedIn", 0);


		$.support.cors=true;

	    $('#login-button').on('click', function(){

	        if($('#username').val().length > 0 && $('#password').val().length > 0){

	            loginCredentials.username = $('#username').val();
	            loginCredentials.password = $('#password').val();  
	            auth(loginCredentials, handleAuth);
	        
	        }

	        else {

	            alert('all fields are required');
	        }
	    });  
	}

	function handleAuth(msg,data){
		switch(msg) {
    case 'success':
    	user=data;
    	loginCredentials={ username : "", password : "" };
    	document.getElementById("password").value=""; 
    	window.localStorage.setItem("loggedIn", 1);

		autorefresh = setInterval(
			function(){ 

				getDemandes(user.activite,updateList); 

			}, 600000);

    	


        $.mobile.changePage( "#index");
        break;
    case 'credentialsError':
        alert('mauvais mdp ou nom d\'utilisateur');
        break;
    case 'requestError':
        alert('erreur, rééssayez plus tard');
		} 

	}


	function beforeShowPageLogin(){
		console.log('beforeShowPageLogin : connected : '+window.localStorage.getItem("loggedIn"));


		if(window.localStorage.getItem("loggedIn") == 1){

	        $.mobile.changePage( "#index", { transition: "none"} );
	    }


	}

	function beforeShowPageHome(){ 
		console.log('beforeShowPageHome : connected : '+window.localStorage.getItem("loggedIn"));

		$.support.cors=true;;
		

	
		if(window.localStorage.getItem("loggedIn") == 1){

			$('#logout-button').on('click', function(){


				clearInterval(autorefresh);
				window.localStorage.setItem("loggedIn", 0);
				$('#headTitle').empty();
				$.mobile.changePage( "#login", {transition : "pop"} );


			});

			$('#refresh-button').on('click', function(){


			getDemandes(user.activite,updateList);


			});	

		    getDemandes(user.activite,updateList);

		    $(this).find('[data-role="header"] h3').empty();
		    $(this).find('[data-role="header"] h3').append('connecté : ' + user.nomEnt);	    	  
		     
		}else{

			$.mobile.changePage( "#login", { transition: "none"} );
		}



	}

	function setupPageHome(){

		if(window.localStorage.getItem("loggedIn") == 0){

	        $.mobile.changePage( "#login", { transition: "none"} );
	    }else{

	    		
	    }


	}



	function beforeShowDetail(){
		console.log('beforeShowDetail : connected : '+window.localStorage.getItem("loggedIn"));
//$('#mailText').css("width" , "200px");


		if(window.localStorage.getItem("loggedIn") == 0){

	        $.mobile.changePage( "#login", { transition: "none"} );
	    }

		$('#Retour-button').on('click', function(){
			$('#nomEnt').empty();
			$('#descDemande').empty();
			$('#etatDemande').empty();
			$.mobile.changePage( "#index", {transition : "slide"} );

		});


	
	}


		

	

	function toDetail(data){
		console.log('toDetail id : '+data);

		getOneDemande(data,updateDetail);
		$.mobile.changePage( "#detail", { transition: "none"} );

	}

	function updateDetail(data){

		var mail = { 
			idEntreprise : user._id,
			idDemande : data._id,
			
		}

		$('#nomEnt').append("<h1>"+ data.nomEnt + "</h1>");
		$('#descDemande').append( data.descDemande);
		$('#etatDemande').append( data.etatDemande );



		$('#send').on('click', function(){

			mail.mailText = $("#mailText").val();
			sendMail(mail, mailSent);

		});




	}

	function mailSent(data){
		console.log(data);

		if (data == "error"){
			alert('echec d\'envoi du mail');


		}
		else {
			document.getElementById("mailText").value=""; 

		}
	}




	$(document).on('pagecreate', '#login', setupPageLogin);
	$(document).on('pagecreate', '#index', setupPageHome);
	$(document).on('pagebeforeshow', '#login', beforeShowPageLogin);
	$(document).on('pagebeforeshow', '#index', beforeShowPageHome);
	$(document).on('pagebeforeshow', '#detail', beforeShowDetail);


	
