$.support.cors=true;



function auth(loginData, callback){ // récupère les infos de l'utilisateur pour vérifier les identifiants
		console.log(loginData);
		$.ajax({

			type : 'GET',
			url: 'http://localhost:5000/entreprises/'+loginData.username, // modifier l'url pour correspondre avec l'api
			dataType: 'json',
			success: function (result) {



				if(result.password == loginData.password) {


					callback('success',result);

					
				} 

				else {


					callback('credentialsError',null);
				
				}

			},

			error: function (request,error) {

				callback('requestError',null);
				
			}
		});
}

