$.support.cors=true;


function getDemandes(secteur,callback){  // récupère les demandes du même secteur d'activité

	var demandes= [];
	var dem = {
								_id : "",
								nomEnt : "",
								adresseEnt :"" ,
								cpEnt :"" ,
								villeEnt :"" ,
								telEnt : "", 
								mailEnt :"" , 
								secteurDemande :"" , 
								descDemande :"" , 
								etatDemande :"" }
	var res;
				$.ajax({
					type : 'GET',
			        url: 'http://localhost:5000/demandes?where={%22secteurDemande%22:%20%22' + secteur + '%22}', // modifier l'url pour correspondre avec l'api
			   		dataType: 'json',


			   		beforeSend: function() {
			   			console.log('beforeSend')
			   			$.mobile.loading('show');
			   		},
			   		complete: function() {
			   			$.mobile.loading('hide');
			   		},
					success: function (result) {
					    	
						for (var i=0; i<result._items.length; i++){
								
								
								demandes.push(
									{
								_id : result._items[i]._id,
								nomEnt :result._items[i].nomEnt ,
								adresseEnt :result._items[i].adresseEnt ,
								cpEnt : result._items[i].cpEnt,
								villeEnt : result._items[i].villeEnt,
								telEnt : result._items[i].telEnt, 
								mailEnt : result._items[i].mailEnt, 
								secteurDemande :result._items[i].secteurDemande , 
								descDemande : result._items[i].descDemande, 
								etatDemande : result._items[i].etatDemande}
								);
						}
						demandes.reverse();
						callback(demandes);					
					},
					error: function (request,error) {
					callback('erreur demandes');

					}

			});
			return;
}


function getOneDemande(id,callback){ // récupère les infos d'une demande via l'id, pour l'affichage des détails

		var dem = {
								_id : "",
								nomEnt : "",
								adresseEnt :"" ,
								cpEnt :"" ,
								villeEnt :"" ,
								telEnt : "", 
								mailEnt :"" , 
								secteurDemande :"" , 
								descDemande :"" , 
								etatDemande :"" }

	$.ajax({
		type : 'GET',
	    url: 'http://localhost:5000/demandes/'+id, // modifier l'url pour correspondre avec l'api
			dataType: 'json',


		success: function (result) {
			


								dem._id = result._id;
								dem.nomEnt = result.nomEnt;
								dem.adresseEnt =result.adresseEnt ;
								dem.cpEnt =result.cpEnt ;
								dem.villeEnt =result.villeEnt ;
								dem.telEnt =result.telEnt ; 
								dem.mailEnt =result.mailEnt ;
								dem.secteurDemande =result.secteurDemande;
								dem.descDemande =result.descDemande ; 
								dem.etatDemande =result.etatDemande;
								callback(dem);
		
		},

		error: function (request,error) {

			callback('impossible de récupérer les détails');

		}

	});


}
